import-module servermanager
add-windowsfeature web-server -includeallsubfeature