New-AzVm `
    -ResourceGroupName 'rg-dev-01' `
    -Name 'vm03' `
    -Location 'East US' `
    -VirtualNetworkName 'vnet01' `
    -SubnetName 'subnet01' `
    -PublicIpAddressName 'publicip03' `
    -OpenPorts 80,3389 `
    -Size Standard_B1s