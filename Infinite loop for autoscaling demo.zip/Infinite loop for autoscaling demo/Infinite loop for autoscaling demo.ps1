for (;;)
{
Echo "Looping"
}