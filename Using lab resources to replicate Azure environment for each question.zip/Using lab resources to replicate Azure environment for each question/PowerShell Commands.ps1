cd "D:\Working Folder"

Connect-AzAccount

New-AzResourceGroupDeployment -ResourceGroupName "rg-dev-02" -TemplateFile "labsetup.json"